/**
 * parser.test.ts
 * Tests the parser and props builders against the real cookbook markdown files.
 * Run: npx ts-node --compiler-options '{"module":"commonjs","types":["node"]}' parser.test.ts
 */

import { parseRecipeMarkdown } from "./parser";
import {
  recipeToPageProps,
  recipeToCardProps,
  buildCookbookIndexProps,
  scaleRecipePageProps,
} from "./props";

// ─── Real markdown from the Cookbook Google Drive folder ─────────────────────

const CELERIAC_MD = `# Celeriac with Kimchi Remoulade

> A French bistro classic reoriented toward Korea: raw celeriac and carrot cut into matchsticks, dressed in a kimchi-spiked mayonnaise with capers, dried shrimp, and horseradish. The texture is everything — do not grate.

**Serves:** 4–6 | **Time:** ~25 minutes

---

## Ingredients

| Qty | Ingredient |
|-----|------------|
| 1 medium | Celeriac (celery root), trimmed, peeled, cut into matchsticks (~1/8" square × 1.5" long) |
| 1 medium | Carrot, cut into matchsticks |
| 1 stalk | Celery, preferably with leaves, finely chopped |
| ½ cup | Choi's green cabbage kimchi, roughly chopped |
| ¼ cup | Dried shrimp, finely chopped |
| 2 tbsp | Capers in sea salt |
| ¼ cup | Duke's mayonnaise |
| 2 tbsp | Extra virgin olive oil |
| 1 tbsp | Whole grain mustard |
| 1 tbsp | Fresh horseradish, grated (or 1 tsp prepared) |
| 2 cloves | Garlic, crushed or grated |
| 1 tbsp | Ketchup |
| 1 tbsp | Apple cider vinegar |
| ½ tsp | Fine sea salt |
| ½ tsp | Sugar |

---

## Method

### 1. Soak the capers
Soak capers in cold water for 15 minutes to draw out excess salt. Drain and chop coarsely.

### 2. Build the dressing
Dissolve the salt and sugar in the vinegar in a large bowl. Add the mayonnaise, olive oil, kimchi, chopped capers, mustard, horseradish, garlic, and ketchup. Mix until combined.

### 3. Add the vegetables and serve
Add the celeriac, carrot, and celery to the bowl and toss to coat thoroughly. Taste and adjust salt. Serve at room temperature — cold dulls the flavors.

---

## Notes

**Cut, don't grate:** A box grater shreds celeriac too finely and turns the salad into mush. The matchstick cut — roughly 1/8" square and 1.5" long — preserves texture and gives the dressing something to cling to rather than drown. A food processor with a julienne disc is the acceptable shortcut; a box grater is not.

**Kimchi:** The recipe calls for green cabbage kimchi specifically (Choi's is the source). Napa cabbage kimchi works but is wetter and more intensely flavored — reduce slightly and drain before chopping.

**Dried shrimp:** Adds a layer of background umami rather than a detectable seafood note. Don't skip it. Found in most Asian grocery stores; finely chop so it integrates rather than punctuates.

**Make-ahead:** The salad holds at room temperature for 1–2 hours as the celeriac continues to soften slightly in the dressing. Beyond that, refrigerate — it keeps a day, though the texture will soften further.
`;

const BRUSSELS_MD = `# Brussels Sprouts Kimchi

> Dense, tightly layered sprouts that most kimchi recipes render dry and unevenly fermented — fixed here with quartered cuts, a light 3% brine, and a fluid fruit-based paste that flows between the leaves rather than sitting on the surface.

**Serves:** 4 (yields ~0.8L jar) | **Time:** ~30 minutes active + 1 hr brining + 1–2 days fermentation

---

## Ingredients

### Brine
| Qty | Ingredient |
|-----|------------|
| 500ml | Water |
| 15g (1¼ tbsp) | Coarse sea salt |

### Kimchi Paste
| Qty | Ingredient |
|-----|------------|
| 70g (¼ fruit) | Asian pear or crisp apple (Fuji or Gala), roughly chopped |
| 30g (¼ medium) | Onion, roughly chopped |
| 8g (~2 cloves) | Garlic, lightly crushed |
| 2g (1 thin slice) | Fresh ginger |
| 2 tbsp | Gochugaru (Korean red chili powder) |
| 1 tbsp | Anchovy sauce or fish sauce *(vegan: 1½ tbsp guk-ganjang)* |
| 15g (1 stalk) | Green onion, sliced diagonally |

### Main
| Qty | Ingredient |
|-----|------------|
| 500g | Brussels sprouts, cut into quarters through the stem |

### To Finish
| Qty | Ingredient |
|-----|------------|
| ½ cup | Water |
| ½ tsp | Coarse sea salt |

---

## Method

### 1. Prep the sprouts
Rinse briefly if needed. Cut each sprout through the stem into quarters — the stem holds the leaves together and prevents them from disintegrating.

### 2. Brine
Dissolve the salt completely in the water to make a 3% brine. Add the sprouts and keep them fully submerged. Brine for 1 hour, turning gently once halfway through.

### 3. Drain — do not rinse or squeeze
After brining, drain for about 10 minutes to shed surface liquid. Do not rinse and do not squeeze.

### 4. Blend the paste base
Blend the Asian pear (or apple) and onion until smooth. Add the garlic and ginger, then pulse until finely minced.

### 5. Finish the paste
Transfer the blended base to a bowl. Add gochugaru, fish sauce, and green onion. Mix until the paste is loose and fluid.

### 6. Combine
Add the drained sprouts to the paste. Mix very gently — no squeezing, no pressing. Stop once the sprouts are uniformly glossy.

### 7. Pack the jar
Transfer the kimchi to a clean 0.8-litre jar. Press just enough to eliminate air pockets without compacting the vegetables.

### 8. Ferment at room temperature
Ferment at 18–20°C (65–70°F) for 1–2 days. Readiness signals: a lightly tangy aroma and small bubbles visible in the brine.

### 9. Refrigerate
Move the jar to the refrigerator. Best within the first 1 to 1½ months when texture is lively and acidity is balanced.

---

## Notes

**Why not a standard cabbage kimchi method:** Brussels sprouts are dense and release very little natural water.

**No starch slurry:** Cabbage kimchi uses a porridge or slurry for binding because cabbage needs it. Brussels sprouts don't.

**Fermentation cues over timing:** The 1–2 day window is a starting point. Trust the tangy smell and bubble activity over the calendar.

**Vegan substitution:** Replace fish sauce with 1½ tbsp guk-ganjang (Korean light soy sauce).
`;

const SLAW_MD = `# Shaved Brussels Sprout Slaw with Citrus-Dijon Vinaigrette

> Raw Brussels sprouts shredded thin and macerated in a mustardy lime-champagne vinaigrette — bright, bitter, and punchy, with craisins and toasted nuts for contrast.

**Serves:** 4 | **Time:** ~25 minutes

---

## Ingredients

### Vinaigrette
| Qty | Ingredient |
|-----|------------|
| 3 tbsp | Citrus champagne vinegar |
| 1 tbsp | Lime juice (bottled 100% is fine) |
| 1½ tbsp | Grey Poupon Dijon mustard |
| 1 | Garlic clove, minced or grated |
| 1 | Shallot, finely minced |
| 1 tsp | Honey or maple syrup |
| ¼ cup | Olive oil, good quality |
| ¾ tsp | Kosher salt |
| ½ tsp | Black pepper, freshly cracked |

### Slaw
| Qty | Ingredient |
|-----|------------|
| 12 oz | Brussels sprouts, shredded |
| ⅓ cup | Craisins |
| ⅓ cup | Toasted nuts (pecans, almonds, or walnuts) |
| 2 oz | Parmesan or Pecorino, shaved or grated *(optional)* |

---

## Method

### 1. Make the vinaigrette
Whisk together the vinegar, lime juice, Dijon, garlic, shallot, honey, salt, and pepper until combined. Slowly drizzle in the olive oil while whisking constantly to emulsify.

### 2. Dress and macerate
Toss the shredded Brussels sprouts with about two-thirds of the dressing and a pinch of salt. Let sit for at least 10–15 minutes.

### 3. Toast the nuts
Toast the nuts in a dry skillet over medium heat, stirring frequently, until fragrant and lightly golden — about 3–4 minutes.

### 4. Finish and serve
Fold in the craisins, toasted nuts, and cheese if using. Add remaining dressing to taste. Adjust salt and acid.

---

## Notes

**Maceration is the work:** Don't shortcut the rest time. Ten minutes minimum; fifteen is better.

**Lime over lemon here:** Lime's sharper, more distinct acidity contrasts the champagne vinegar rather than doubling up on the same citrus note.

**Make-ahead:** Dressing keeps refrigerated up to one week. The dressed slaw holds a day in the fridge — add nuts and craisins just before serving so they don't go soft.
`;

// ─── Tiny test harness ────────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

function assert(cond: boolean, label: string): void {
  if (cond) { console.log(`  ✓ ${label}`); passed++; }
  else       { console.error(`  ✗ ${label}`); failed++; }
}

function section(title: string): void {
  console.log(`\n── ${title} ──`);
}

// ─── Parser tests ─────────────────────────────────────────────────────────────

section("Celeriac recipe — flat (ungrouped) ingredients");
const celeriac = parseRecipeMarkdown(CELERIAC_MD, "celeriac-kimchi-remoulade.md");

assert(celeriac.title === "Celeriac with Kimchi Remoulade", "title parsed");
assert(celeriac.tagline.includes("French bistro"), "tagline parsed");
assert(celeriac.meta.serves === "4–6", "serves parsed");
assert(celeriac.meta.time === "~25 minutes", "time parsed");
assert(celeriac.ingredientGroups.length === 1, "one ingredient group (flat)");
assert(celeriac.ingredientGroups[0].groupName === undefined, "no group name on flat list");
assert(celeriac.ingredientGroups[0].ingredients.length === 15, "15 ingredients");
assert(celeriac.ingredientGroups[0].ingredients[0].qty === "1 medium", "first qty");
assert(celeriac.ingredientGroups[0].ingredients[0].name.startsWith("Celeriac"), "first name");
assert(celeriac.steps.length === 3, "3 method steps");
assert(celeriac.steps[0].stepNumber === 1, "step 1 number");
assert(celeriac.steps[0].title === "Soak the capers", "step 1 title");
assert(celeriac.steps[0].body.includes("Soak capers"), "step 1 body");
assert(celeriac.notes.length === 4, "4 notes");
assert(celeriac.notes[0].label === "Cut, don't grate", "note 1 label");
assert(celeriac.notes[0].body.includes("box grater"), "note 1 body");
assert(celeriac.notes[3].label === "Make-ahead", "note 4 label");

section("Brussels Sprouts Kimchi — grouped ingredients");
const brussels = parseRecipeMarkdown(BRUSSELS_MD, "brussels-sprouts-kimchi.md");

assert(brussels.title === "Brussels Sprouts Kimchi", "title parsed");
assert(brussels.meta.serves === "4 (yields ~0.8L jar)", "complex serves string parsed");
assert(brussels.meta.time.includes("brining"), "multi-part time parsed");
assert(brussels.ingredientGroups.length === 4, "4 ingredient groups");
assert(brussels.ingredientGroups[0].groupName === "Brine", "group 0: Brine");
assert(brussels.ingredientGroups[1].groupName === "Kimchi Paste", "group 1: Kimchi Paste");
assert(brussels.ingredientGroups[2].groupName === "Main", "group 2: Main");
assert(brussels.ingredientGroups[3].groupName === "To Finish", "group 3: To Finish");
assert(brussels.ingredientGroups[0].ingredients.length === 2, "Brine has 2 ingredients");
assert(brussels.ingredientGroups[1].ingredients.length === 7, "Paste has 7 ingredients");
assert(brussels.steps.length === 9, "9 method steps");
assert(brussels.steps[8].stepNumber === 9, "last step is #9");
assert(!("isLast" in brussels.steps[8]), "isLast absent from ParsedRecipe step");
assert(brussels.notes.length === 4, "4 notes");
assert(brussels.notes[0].label === "Why not a standard cabbage kimchi method", "first note label");

section("Slaw — also grouped ingredients");
const slaw = parseRecipeMarkdown(SLAW_MD, "shaved-brussels-sprout-slaw-citrus-dijon.md");

assert(slaw.ingredientGroups.length === 2, "2 ingredient groups");
assert(slaw.ingredientGroups[0].groupName === "Vinaigrette", "group 0: Vinaigrette");
assert(slaw.ingredientGroups[1].groupName === "Slaw", "group 1: Slaw");
assert(slaw.ingredientGroups[0].ingredients.length === 9, "9 vinaigrette ingredients");
assert(slaw.ingredientGroups[1].ingredients.length === 4, "4 slaw ingredients");
assert(slaw.steps.length === 4, "4 method steps");
assert(slaw.notes.length === 3, "3 notes");

// ─── Props builder tests ──────────────────────────────────────────────────────

section("recipeToPageProps — celeriac");
const celeriacProps = recipeToPageProps(celeriac, {
  imageUrl: "/images/celeriac-kimchi-remoulade.jpg",
});

assert(celeriacProps.slug === "celeriac-with-kimchi-remoulade", "slug derived from title");
assert(celeriacProps.hero.title === "Celeriac with Kimchi Remoulade", "hero title");
assert(celeriacProps.hero.serves === "4–6", "hero serves");
assert(celeriacProps.hero.imageUrl === "/images/celeriac-kimchi-remoulade.jpg", "hero imageUrl");
assert(celeriacProps.ingredients.totalCount === 15, "totalCount");
assert(celeriacProps.ingredients.groups[0].groupIndex === 0, "groupIndex populated");
assert(celeriacProps.ingredients.groups[0].ingredients[0].index === 0, "row index populated");
assert(celeriacProps.method.totalSteps === 3, "totalSteps");
assert(celeriacProps.method.steps[0].index === 0, "step index populated");
assert(celeriacProps.method.steps[0].isLast === false, "isLast false on first step");
assert(celeriacProps.method.steps[2].isLast === true, "isLast true on last step");
assert(celeriacProps.notes.notes[0].index === 0, "note index populated");
assert(celeriacProps.notes.notes[0].label === "Cut, don't grate", "note label in props");

section("recipeToPageProps — brussels (grouped)");
const brusselsProps = recipeToPageProps(brussels);

assert(brusselsProps.ingredients.groups.length === 4, "4 groups in props");
assert(brusselsProps.ingredients.groups[1].groupName === "Kimchi Paste", "group name preserved");
assert(brusselsProps.ingredients.groups[1].groupIndex === 1, "groupIndex = 1");
assert(brusselsProps.ingredients.totalCount === 12, "12 total ingredients across all groups");
assert(brusselsProps.method.steps[8].isLast === true, "step 9 isLast = true");

section("recipeToCardProps");
const card = recipeToCardProps(celeriac, { imageUrl: "/img/celeriac.jpg" });
assert(card.title === "Celeriac with Kimchi Remoulade", "card title");
assert(card.tagline.includes("French bistro"), "card tagline");
assert(card.serves === "4–6", "card serves");
assert(card.slug === "celeriac-with-kimchi-remoulade", "card slug");
assert(card.imageUrl === "/img/celeriac.jpg", "card imageUrl");

section("buildCookbookIndexProps");
const index = buildCookbookIndexProps([celeriac, brussels, slaw]);
assert(index.totalCount === 3, "index totalCount");
assert(index.recipes[0].slug === "celeriac-with-kimchi-remoulade", "first card slug");
assert(index.recipes[1].slug === "brussels-sprouts-kimchi", "second card slug");
assert(index.recipes[2].slug === "shaved-brussels-sprout-slaw-with-citrus-dijon-vinaigrette", "third card slug");

section("scaleRecipePageProps");
const celeriacPageProps = recipeToPageProps(celeriac);
const doubled = scaleRecipePageProps(celeriacPageProps, 2);
assert(doubled.scaleFactor === 2, "scaleFactor stored");
assert(doubled.originalServes === "4–6", "originalServes preserved");
assert(doubled.hero.serves === "8–12", "serves range scaled correctly");

const brusselsPageProps = recipeToPageProps(brussels);
const halfBatch = scaleRecipePageProps(brusselsPageProps, 0.5);
assert(halfBatch.hero.serves === "2 (yields ~0.8L jar)", "complex serves string scaled (numeric only)");

section("slugOverride");
const custom = recipeToPageProps(celeriac, { slugOverride: "my-custom-slug" });
assert(custom.slug === "my-custom-slug", "slugOverride respected");

// ─── Summary ─────────────────────────────────────────────────────────────────
console.log(`\n${"─".repeat(45)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
